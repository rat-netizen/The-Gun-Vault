const products = [
  {
    name: "Tactical Pistol",
    price: "5000 UAH",
    image: "https://via.placeholder.com/200",
  },
  {
    name: "Air Rifle",
    price: "3000 UAH",
    image: "https://via.placeholder.com/200",
  },
  {
    name: "Gas Pistol",
    price: "4500 UAH",
    image: "https://via.placeholder.com/200",
  },
  {
    name: "Hunting Rifle",
    price: "8000 UAH",
    image: "https://via.placeholder.com/200",
  },
];

const productList = document.getElementById("product-list");

products.forEach((product) => {
  const productCard = document.createElement("div");
  productCard.classList.add("product");

  productCard.innerHTML = \`
    <img src="\${product.image}" alt="\${product.name}">
    <h3>\${product.name}</h3>
    <p>Price: \${product.price}</p>
  \`;

  productList.appendChild(productCard);
});